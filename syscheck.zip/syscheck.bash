#!/bin/bash
cd /home/chris/syscheck/

./syscheck-1.3.bash
./syscheck-9.0.bash

